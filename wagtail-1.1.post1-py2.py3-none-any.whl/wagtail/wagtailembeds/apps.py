from django.apps import AppConfig


class WagtailEmbedsAppConfig(AppConfig):
    name = 'wagtail.wagtailembeds'
    label = 'wagtailembeds'
    verbose_name = "Wagtail embeds"
