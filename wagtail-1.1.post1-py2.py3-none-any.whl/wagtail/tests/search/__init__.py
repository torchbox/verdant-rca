default_app_config = 'wagtail.tests.search.apps.WagtailSearchTestsAppConfig'
