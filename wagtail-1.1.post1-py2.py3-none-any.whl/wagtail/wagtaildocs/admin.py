from django.contrib import admin

from wagtail.wagtaildocs.models import Document

admin.site.register(Document)
