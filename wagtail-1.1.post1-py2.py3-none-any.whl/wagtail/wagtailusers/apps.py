from django.apps import AppConfig


class WagtailUsersAppConfig(AppConfig):
    name = 'wagtail.wagtailusers'
    label = 'wagtailusers'
    verbose_name = "Wagtail users"
