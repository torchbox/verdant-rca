class RemovedInWagtail12Warning(DeprecationWarning):
    pass


removed_in_next_version_warning = RemovedInWagtail12Warning


class RemovedInWagtail13Warning(PendingDeprecationWarning):
    pass
